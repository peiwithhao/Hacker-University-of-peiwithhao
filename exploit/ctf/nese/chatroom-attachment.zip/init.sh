#!/bin/sh
# Add your startup script
#!/bin/sh

# if need dynamic flag

# DO NOT DELETE
/etc/init.d/xinetd start;
sleep infinity;