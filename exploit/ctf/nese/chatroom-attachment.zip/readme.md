## protoc version

```bash
❯ protoc --version                                                      
libprotoc 29.3
                                             
❯ pip3 show protobuf                                                         
Name: protobuf
Version: 5.29.3
Summary: 
Home-page: https://developers.google.com/protocol-buffers/
Author: protobuf@googlegroups.com
Author-email: protobuf@googlegroups.com
License: 3-Clause BSD License

```

## build

```bash
docker compose up -d
nc 0.0.0.0 70 to exploit
nc 0.0.0.0 1234 to debug
```

